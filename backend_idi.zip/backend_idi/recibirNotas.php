<?php

//Este archivo envía la información de nombre, apellido y nota a la base de datos

require_once('conexion.php');

$nombre=$_GET['nombre'];
// $id=$_GET['id'];
$ubicacion=$_GET['ubicacion'];



$conn=new conexion();

//Insertar en Estudiantes la nota
// INSERT INTO `Estudiantes` (`id`, `nombre`, `apellido`, `nota`) VALUES (NULL, 'Maxi', 'Espinola', '10');


//Hacemos la consulta de SQL para actualizar tabla HISTORICO

//Primero, preparamos la variable $queryINSERT con la consulta a la base de datos para insertar los datos recibidor por GET
$queryINSERT="INSERT INTO `plantas` (`nombre`, `ubicacion`) VALUES ('$nombre', '$ubicacion');";

//Ejercutamos la consulta a la base de datos
$insert= mysqli_query($conn->conectardb(),$queryINSERT);


//
echo "Se cargaron los datos}";

PRINT <<<HERE

<a href="formCargaNotas.html">
<button >Registrar otra planta</button>
</a>

HERE;
?>