<h1>titulo</h1>
<?php

//Este archivo recibe un nombre y un apellido y realiza una consulta para ver la nota de ese nombre y apellido


require_once('conexion.php');

// $nombre=$_GET['nombre'];
// $ubicacion=$_GET['ubicacion'];
// $id=$_GET['id']

$conn=new conexion();

//Hacemos la consulta de SQL para buscar el nombre y apellido
// $querySELECT= "(`nombre`, `ubicacion`  FROM `Estudiantes` WHERE `apellido`='Esp' AND `nombre`='Max'";
// $querySELECT="SELECT * FROM `plantas`";

//INSERT INTO `historico` (`dispositivo`, `temperatura`, `humedad`, `servo`, `led`, `fechaRegistro`) VALUES ('node1', '11', '11', '11', '1', '2021-11-02 15:23:19.000000');
//primer parametro la conexion, el segundo la consulta
$result= mysqli_query($conn->conectardb(),$querySELECT);


//Creo una variable $row (fila) en la cual vamos a guardar la fila que nos da como resultado la consulta SELECT
// $row=mysqli_fetch_row($result);
// echo ($row=mysqli_fetch_row($result));
return $result;
// echo "La planta:" .$nombre."esta en" .$ubicacion;    

?>