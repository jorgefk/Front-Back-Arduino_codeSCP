
<?php
require_once('conexion.php');

$conn=new conexion();

$querySELECT="SELECT  nombre FROM plantas";

$result= mysqli_query($conn->conectardb(),$querySELECT);


$connect = mysqli_connect('localhost', 'root', '', 'proyecto_idi');

$query = 'SELECT nombre 
FROM plantas WHERE id = "3"
-- WHERE fecha = (SELECT MAX( fecha ) FROM estado);';

$result = mysqli_query($connect, $query);

while($row = mysqli_fetch_assoc($result)) {
    echo "<h2> " . $row["nombre"].  " </h2>";
}


?>